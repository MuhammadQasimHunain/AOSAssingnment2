//
//  main.c
//  Assignment2-Client
//
//  Created by Hassaan on 05/04/2017.
//  Copyright © 2017 HaigaTech. All rights reserved.
//

//#include <stdio.h>
//
//int main(int argc, const char * argv[]) {
//    // insert code here...
//    printf("Hello, World!\n");
//    return 0;
//}
